contract OracleRouter {}
